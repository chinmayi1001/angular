## create new application

    ng new app-name

## create 3 components

    ng g c signup

    ng g c login
    
    ng g c profile

## start angular

    ng serve

## install json-server (globally)

    npm i -g json-server

## create new file `db.json` in project

## start json-server

    json-server --watch db.json